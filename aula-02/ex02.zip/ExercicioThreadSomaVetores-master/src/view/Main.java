package view;

import java.util.Random;

import controller.ThreadCalc;

public class Main {

	public static void main(String[] args) {
		
		int linhas = 3;
		int colunas = 5;

		int[][] arr = preencheArray(linhas, colunas);


		for (int i = 0; i < arr.length; i++) {

			Thread calc = new ThreadCalc(arr[i], i);
			calc.start();
		}

	}

	private static int[][] preencheArray(int linhas, int colunas) {

		Random rand = new Random();

		int[][] arr = new int[linhas][colunas];

		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				arr[i][j] = rand.nextInt(50);
			}
		}

		return arr;
	}

}
