package controller;

public class ThreadCalc extends Thread {
	
	int vet[];
	int linha;
	
	public ThreadCalc(int vet[], int linha) {
		this.vet = vet;
		this.linha = linha;
		
	}
	
	@Override
	public void run() {
		
		int total = calculaSoma();

		System.out.println("Soma da linha " + linha + " = " + total);
		
	}
	
	private int calculaSoma() {
		int total = 0;
		for (int a : vet) {
			total += a;
		}
		
		return total;
	}
	
	
}
