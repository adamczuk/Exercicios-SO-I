package controller;

public class ThreadId extends Thread {

	public ThreadId() {
	}

	@Override
	public void run() {
		imprimeId();
	}

	private void imprimeId() {
		System.out.println("ID da thread atual: " + getId());
	}
}
