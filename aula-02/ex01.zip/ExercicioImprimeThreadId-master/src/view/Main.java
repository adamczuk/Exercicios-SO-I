package view;

import controller.ThreadId;

public class Main {
	public static void main(String[] args) {
		for (int id = 0; id < 5; id++) {
			 ThreadId threadId = new ThreadId();
			 threadId.start();
		}
	}
}
