package controller;

import java.util.Random;
import java.util.concurrent.Semaphore;

public class VendaController extends Thread {

	private static int qtdeDisponivel = 100;

	private int qtdeDesejada;
	private int idUsuario;
	private Semaphore semaforo;

	public VendaController(int idUsuario, int qtdeDesejada, Semaphore semaforo) {
		this.idUsuario = idUsuario;
		this.qtdeDesejada = qtdeDesejada;
		this.semaforo = semaforo;
	}

	@Override
	public void run() {
		if (usuarioLogou()) {
			if (usuarioComprou()) {
				try {
					semaforo.acquire();
					validarCompra();
				} catch (InterruptedException e) {
					e.printStackTrace();
				} finally {
					semaforo.release();
				}
			}
		}

	}

	private boolean usuarioLogou() {

		int tempoLogin = new Random().nextInt(1951) + 50;
		try {
			sleep(tempoLogin);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		if (tempoLogin > 1000) {
			System.err.println(
					"\nUsuario " + idUsuario + " demorou demais para fazer login. Impossivel realizar a compra");
			return false;
		} else {
			return true;
		}

	}

	private boolean usuarioComprou() {

		int tempoCompra = new Random().nextInt(201) + 100;
		try {
			sleep(tempoCompra * 10);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		if (tempoCompra > 250) {
			System.err.println("\nUsuario " + idUsuario + ": Tempo de compra excedido. Impossivel realizar a venda");
			return false;
		} else {
			return true;
		}
	}

	private void validarCompra() {

		if (qtdeDesejada <= qtdeDisponivel) {
			qtdeDisponivel -= qtdeDesejada;
			System.out.println("\nUsuario " + idUsuario + " comprou " + qtdeDesejada + " ingressos."
					+ " \nINGRESSOS DISPONIVEIS: " + qtdeDisponivel);
		} else {
			System.err.println("\nUsuario " + idUsuario + ": Impossivel realizar a venda."
					+ " Quantidade desejada � maior que dispon�vel" + "\nQUANTIDADE DESEJADA: " + qtdeDesejada
					+ "\nQUANTIDADE DISPONIVEL: " + qtdeDisponivel);
		}

	}

}
