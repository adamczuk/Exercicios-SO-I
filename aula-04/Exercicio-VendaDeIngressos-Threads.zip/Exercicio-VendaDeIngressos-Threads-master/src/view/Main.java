package view;

import java.util.Random;
import java.util.concurrent.Semaphore;

import controller.VendaController;

public class Main {
	
	public static void main(String[] args) {
		Semaphore semaforo = new Semaphore(1);
		
		int qtdeDesejada = 0;
		Random rand = new Random();
		
		for (int idUsuario = 1 ; idUsuario <= 300 ; idUsuario++) {
			qtdeDesejada = rand.nextInt(4) + 1;
			VendaController vCont = new VendaController (idUsuario, qtdeDesejada, semaforo);
			vCont.start();
			
		}
	}

}
