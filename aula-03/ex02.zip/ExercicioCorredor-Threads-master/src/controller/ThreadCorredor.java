package controller;

import java.util.Random;
import java.util.concurrent.Semaphore;

public class ThreadCorredor extends Thread {

	int numCorredor, tamanhoCorredor;
	Semaphore s1;

	public ThreadCorredor(int numCorredor, int tamanhoCorredor, Semaphore s1) {
		this.numCorredor = numCorredor;
		this.tamanhoCorredor = tamanhoCorredor;
		this.s1 = s1;
	}

	@Override
	public void run() {
		
		andando();

		try {
			s1.acquire();
			cruzarPorta();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			s1.release();
		}
	}

	private void andando() {
		int distanciaPercorrida = 0;
		Random rand = new Random();

		while (distanciaPercorrida < tamanhoCorredor) {
			distanciaPercorrida += rand.nextInt(3) + 4;
			
			try {
				sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if (distanciaPercorrida >= tamanhoCorredor) {
				distanciaPercorrida = tamanhoCorredor;
				System.out.println("A pessoa do corredor " + numCorredor + " chegou na porta");
			} else {
				System.out.println("A pessoa do corredor " + numCorredor + " andou " + distanciaPercorrida + " m.");
			}
		}

	}

	private void cruzarPorta() {
		Random rand = new Random();
		System.out.println("A pessoa do corredor " + numCorredor + " esta cruzando a porta");
		try {
			sleep((rand.nextInt(2) + 1) * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println("A pessoa do corredor " + numCorredor + " cruzou a porta");

	}

}
