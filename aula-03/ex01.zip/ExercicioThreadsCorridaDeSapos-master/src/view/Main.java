package view;

import controller.ThreadCorrida;

public class Main {
	public static void main(String[] args) {
		
		int total = 100;
		int saltoMaximo = 20;
		
		for (int i = 1; i < 6; i++) {
			
			ThreadCorrida sapo = new ThreadCorrida(total, saltoMaximo, i);
			
			sapo.start();
		}
	}
}
