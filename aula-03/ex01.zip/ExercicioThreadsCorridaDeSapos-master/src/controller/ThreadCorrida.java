package controller;

import java.util.Random;

public class ThreadCorrida extends Thread {

	int tamanho;
	int saltoMaximo;
	int id;

	public ThreadCorrida(int tamanho, int saltoMaximo, int id) {

		this.tamanho = tamanho;
		this.saltoMaximo = saltoMaximo;
		this.id = id;
	}

	@Override
	public void run() {
		sapoPula();
	}

	private void sapoPula() {

		Random rand = new Random();

		int distanciaPercorrida = 0;
		
		int tamanhoSalto = 0;

		while (distanciaPercorrida < tamanho) {

			tamanhoSalto = rand.nextInt(saltoMaximo);
			if(tamanhoSalto == 0) {
				continue;
			}
			distanciaPercorrida += tamanhoSalto;

			System.out.println("Sapo " + id + " saltou " + tamanhoSalto + "m. Ja pulou " + distanciaPercorrida + "m de "
					+ tamanho + "m.");
		}

	}
}
