
package controller;

import java.util.concurrent.Semaphore;

public class ThreadCruzamento extends Thread {
	
	private int origem;
	private String nomeCarro;
	private Semaphore semaforo;
	
	public ThreadCruzamento(int origem, String nomeCarro, Semaphore semaforo) {
		this.origem = origem;
		this.nomeCarro = nomeCarro;
		this.semaforo = semaforo;
	}
	
	@Override
	public void run() {
		
		try {
			semaforo.acquire();
			cruzar();
			System.out.println("O carro "+nomeCarro+" cruzou.");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		finally {
		semaforo.release();
		}
	}
	
	private void cruzar() {
		String direcao = "";
		switch(origem) {
		case 0:
			direcao = "para baixo";
			break;
		case 1:
			direcao = "para a esquerda";
			break;
		case 2:
			direcao = "para cima";
			break;
		case 3:
			direcao = "para a direita";
			break;
		}
		
		System.out.println("O carro "+ nomeCarro+" esta indo "+direcao);
		
		
	}
	

}
