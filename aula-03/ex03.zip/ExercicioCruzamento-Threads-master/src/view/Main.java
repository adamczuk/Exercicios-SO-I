package view;

import java.util.concurrent.Semaphore;

import controller.ThreadCruzamento;

public class Main {
	
	public static void main(String[] args) {
		Semaphore semaforo = new Semaphore(1);
		
		String[] nomeCarros = {"vermelho", "azul", "amarelo", "verde"};
		
		for (int i = 0; i < 4; i++) {
			String nome = nomeCarros[i];
			ThreadCruzamento tCruz = new ThreadCruzamento(i, nome, semaforo);
			tCruz.start();
		}
	}

}
