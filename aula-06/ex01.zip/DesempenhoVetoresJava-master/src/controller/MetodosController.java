package controller;

import java.util.Random;

public class MetodosController {

	@SuppressWarnings("unused")
	public void calculaTempo(int tamanho) {

		int[] arr1 = popularArray(tamanho);

		double tempoInicial = System.nanoTime();

		for (int posicao : arr1) {

		}

		double tempoFinal = System.nanoTime();

		double tempoTotal = tempoFinal - tempoInicial;

		System.out.println("Tempo total para "+ tamanho+" posi��es ==> " + tempoTotal + "nS. \n");
	}
	
	private int[] popularArray(int tamanho) {
		
		Random rand = new Random();
		int[] arr1 = new int [tamanho];
		
		for (int i = 0; i < arr1.length; i++) {
			arr1[i] = rand.nextInt(50);
		}
		
		return arr1;
		
	}

}