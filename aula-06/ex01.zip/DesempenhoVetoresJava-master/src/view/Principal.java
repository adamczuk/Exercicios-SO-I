package view;

import controller.MetodosController;

public class Principal {

	public static void main(String[] args) {
		MetodosController met = new MetodosController();
		
		met.calculaTempo(1000);
		met.calculaTempo(10000);
		met.calculaTempo(100000);
	}

}
