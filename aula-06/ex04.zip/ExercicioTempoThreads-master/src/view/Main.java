package view;

import java.util.Random;

import controller.ThreadVetor;

public class Main {

	private static int[] vet = new int[1000];
	
	public static void main(String[] args) {
		preencheVetor();
		
		for (int i = 1; i <= 2; i++) {
		ThreadVetor threadTempo = new ThreadVetor(i, vet);
		threadTempo.start();
		}
	}
	
	private static void preencheVetor() {
		Random rand = new Random();
		
		
		for (int i = 0; i < vet.length; i++) {
			vet[i] = rand.nextInt();
		}
	}

}
