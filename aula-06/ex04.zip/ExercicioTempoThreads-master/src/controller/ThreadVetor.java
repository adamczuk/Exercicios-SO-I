package controller;

public class ThreadVetor extends Thread {

	int op;
	int[] vet;

	public ThreadVetor(int op, int[] vet) {

		this.op = op;
		this.vet = vet;

	}

	@Override
	public void run() {
		calculaTempo();

	}

	private void calculaTempo() {

		double tempoInicial;
		double tempoFinal;
		double tempoTotal;

		String tipo = "";

		if (op % 2 == 0) {
			tempoInicial = System.nanoTime();
			percorreFor();
			tempoFinal = System.nanoTime();
			tipo = "For";
		} else {
			tempoInicial = System.nanoTime();
			percorreForeach();
			tempoFinal = System.nanoTime();
			tipo = "Foreach";
		}

		tempoTotal = tempoFinal - tempoInicial;

		tempoTotal = tempoTotal / Math.pow(10, 9);

		System.out.println("Tempo para percorrer o array usando " + tipo + " ==> " + tempoTotal + " segundos");
	}

	private void percorreFor() {
		for (int i = 0; i < vet.length; i++) {

		}
	}

	private void percorreForeach() {
		for (int i : vet) {

		}
	}
}
