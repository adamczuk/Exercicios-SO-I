/*
 * PARA SER THREAD
 * 
 * 1 - herdar Thread
 * 2 - Passar parametros apenas pelo construtor
 * 3 - Deve ter um metodo run
 */

package controller;

public class ThreadId extends Thread {
	
	private int idThread;
	
	public ThreadId(int idThread) {
		this.idThread = idThread;
	}

	@Override
	public void run() {
		
		System.out.println(idThread);
		
	}
}
