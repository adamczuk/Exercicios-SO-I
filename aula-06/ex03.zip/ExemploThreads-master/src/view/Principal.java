package view;

import controller.ThreadCalc;
import controller.ThreadId;

public class Principal {
	
	public static void main(String[] args) {
//		for (int id = 0; id < 5; id++) {
//			Thread threadId = new ThreadId(id);
//			threadId.start();
//		}
		
		int a = 10;
		int b = 5;
		for (int op = 0; op < 4; op++) {
			Thread threadCalc = new ThreadCalc(a, b, op);
			threadCalc.start();
		}
	}

}
