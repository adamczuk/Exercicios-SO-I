package view;

import java.io.IOException;

import javax.swing.JOptionPane;

import controller.RedesController;

public class Main {

	public static void main(String[] args) {
		RedesController redes = new RedesController();
		int opcao = -1;

		do {
			String opcaoJanela = JOptionPane.showInputDialog("Escolha uma opcao: "
					+ "\n1 - Mostrar o nome dos adaptadores de rede com IPv4"
					+ "\n2 - Media do PING para 10 iteracoes em www.google.com.br" + "\n9 - Finalizar o processo");

			if (opcaoJanela == null) {
				opcao = 9;
			} else {

				try {
					opcao = Integer.parseInt(opcaoJanela);

				} catch (NumberFormatException e) {
					JOptionPane.showMessageDialog(null, "APENAS NUMEROS!!");
				}

				switch (opcao) {
				case 1:
					JOptionPane.showMessageDialog(null, redes.ip());
					break;
				case 2:
					JOptionPane.showMessageDialog(null, redes.ping());
					break;
				case 9:
					break;
				default:
					JOptionPane.showMessageDialog(null, "OPCAO INVALIDA. Tente novamente");
					break;
				}
			}
		} while (opcao != 9);

	}

}