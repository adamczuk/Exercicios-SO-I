package controller;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class RedesController {

	public RedesController() {
		super();
	}

	private String os() {
		return System.getProperty("os.name");
	}

	public String ip() {

		String linha = null;
		String msgFinal = "";
		String[] linhaCortada = null;
		String temp = null;

		if (os().contains("Windows")) {

			try {

				Process p = Runtime.getRuntime().exec("ipconfig");
				InputStream stream = p.getInputStream();
				InputStreamReader leitor = new InputStreamReader(stream);
				BufferedReader saida = new BufferedReader(leitor);
				linha = saida.readLine();
				while (linha != null) {
					if (linha.contains("Adaptador")) {
						temp = linha;
					}
					if (linha.contains("IPv4")) {
						linhaCortada = linha.split(":");
						msgFinal += temp + linhaCortada[1] + "\n";
					}
					linha = saida.readLine();
				}

				stream.close();
				leitor.close();
				saida.close();
			} catch (Exception e) {
			}

		} else if (os().contains("Linux")) {

			try {

				Process p = Runtime.getRuntime().exec("ifconfig");
				InputStream stream = p.getInputStream();
				InputStreamReader leitor = new InputStreamReader(stream);
				BufferedReader saida = new BufferedReader(leitor);
				linha = saida.readLine();
				while (linha != null) {
					if (linha.contains(": ")) {
						linhaCortada = linha.split(":");
						temp = linhaCortada[0] + ": ";
					}
					if (linha.contains("inet ")) {
						linhaCortada = linha.split("inet ");
						String temp2 = linhaCortada[1];
						linhaCortada = temp2.split("netmask");
						msgFinal += temp + linhaCortada[0] + "\n";
					}					

					linha = saida.readLine();
				}
				stream.close();
				leitor.close();
				saida.close();
			} catch (Exception e) {
			}

		} else {
			msgFinal = "SO nao suportado";
		}
		
		return msgFinal;
	}
	
	
	


	public String ping() {

		String linha = null;
		String[] linhaCortada = null;
		
		String msgFinal = null;

		if (os().contains("Windows")) {

			try {

				Process p = Runtime.getRuntime().exec("PING -4 -n 10 www.google.com.br");
				InputStream stream = p.getInputStream();
				InputStreamReader leitor = new InputStreamReader(stream);
				BufferedReader saida = new BufferedReader(leitor);
				linha = saida.readLine();
				while (linha != null) {
					if (linha.contains("dia =")) {
						linhaCortada = linha.split(",");
						String temp = linhaCortada[2];
						linhaCortada = temp.split(" = ");
						
						msgFinal =  "Media: "+linhaCortada[1];
					}
					linha = saida.readLine();
				}

				stream.close();
				leitor.close();
				saida.close();
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (os().contains("Linux")) {

			try {

				Process p = Runtime.getRuntime().exec("ping -4 -c 10 www.google.com.br");
				InputStream stream = p.getInputStream();
				InputStreamReader leitor = new InputStreamReader(stream);
				BufferedReader saida = new BufferedReader(leitor);
				linha = saida.readLine();
				while (linha != null) {
					if (linha.contains("min/avg")) {
						linhaCortada = linha.split(" = ");
						String temp = linhaCortada[1];
						linhaCortada = temp.split("/");
						msgFinal = "Media: "+ linhaCortada[1];
					}
					linha = saida.readLine();
				}
				stream.close();
				leitor.close();
				saida.close();
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else {
			msgFinal = "SO nao suportado";
		}
		return msgFinal;
	}
}